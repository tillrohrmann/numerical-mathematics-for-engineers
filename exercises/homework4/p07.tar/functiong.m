function [z] = functiong(x,y)
% Numerical mathematics for engineers 2
% Homework 4
% Programming exercise 7
% Group: nm2-103
% Members: Ana Kosareva, Sophia Kohle, Till Rohrmann
%
% Matlab
    z = (x == 0).*sin(pi*y);
end