function [z] = functionf(x,y)
% Numerical mathematics for engineers 2
% Homework 4
% Programming exercise 7
% Group: nm2-103
% Members: Ana Kosareva, Sophia Kohle, Till Rohrmann
%
% Matlab
z=sparse(numel(x),1);
end